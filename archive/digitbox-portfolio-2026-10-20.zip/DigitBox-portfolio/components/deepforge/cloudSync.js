const CONFIGURED_API_ROOT = (process.env.NEXT_PUBLIC_DEEPFORGE_API || "").replace(/\/$/, "");
const CLOUDFLARE_PAGES_ROOT = "https://digitbox.pages.dev";

function apiRoot() {
  if (
    CONFIGURED_API_ROOT &&
    (
      /^https:\/\/(?:[a-z0-9-]+\.)?digitbox\.pages\.dev$/i.test(CONFIGURED_API_ROOT) ||
      /^https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/i.test(CONFIGURED_API_ROOT)
    )
  ) {
    return CONFIGURED_API_ROOT;
  }
  if (typeof window !== "undefined" && window.location) {
    try { localStorage.removeItem("digitbox-deepforge-api-root-v1"); } catch (_) {}
    const origin = String(window.location.origin || "").replace(/\/$/, "");
    const hostname = String(window.location.hostname || "").toLowerCase();
    if (
      hostname === "digitbox.pages.dev" ||
      hostname.endsWith(".digitbox.pages.dev") ||
      hostname === "localhost" ||
      hostname === "127.0.0.1"
    ) return origin;
    return CLOUDFLARE_PAGES_ROOT;
  }
  return CLOUDFLARE_PAGES_ROOT;
}

export function deepforgeApiRoot() { return apiRoot(); }

const PLAYER_KEY = "digitbox-deepforge-player-id-v1";
const AUTH_KEY = "digitbox-deepforge-auth-v1";
export const CLOUD_AUTH_UPDATED_EVENT = "digitbox:cloud-auth-updated";

export function cloudEnabled() { return true; }

export function getOrCreatePlayerId() {
  if (typeof window === "undefined") return "server";
  let id = localStorage.getItem(PLAYER_KEY);
  if (!id) {
    const random = typeof crypto !== "undefined" && crypto.randomUUID
      ? crypto.randomUUID().replace(/-/g, "")
      : Math.random().toString(36).slice(2) + Date.now().toString(36);
    id = "guest_" + random;
    localStorage.setItem(PLAYER_KEY, id);
  }
  return id;
}

export function getCloudAuthToken() {
  if (typeof window === "undefined") return "";
  try {
    const raw = JSON.parse(localStorage.getItem(AUTH_KEY) || "null");
    return raw && raw.token ? String(raw.token) : "";
  } catch (_) { return ""; }
}

function storeCloudAuth(payload) {
  if (typeof window === "undefined") return payload;
  if (payload && payload.token && payload.user) {
    localStorage.setItem(AUTH_KEY, JSON.stringify({
      token: payload.token,
      user: payload.user,
      expiresAt: payload.expiresAt || 0,
    }));
    window.dispatchEvent(new Event(CLOUD_AUTH_UPDATED_EVENT));
  }
  return payload;
}

export function clearCloudAuth() {
  if (typeof window !== "undefined") {
    localStorage.removeItem(AUTH_KEY);
    window.dispatchEvent(new Event(CLOUD_AUTH_UPDATED_EVENT));
  }
}

async function authRequest(path, options) {
  const root = apiRoot();
  if (!root) throw new Error("Cloudflare API is unavailable.");
  const response = await fetch(root + path, {
    ...options,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      ...((options && options.headers) || {}),
    },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || ("Auth request failed: " + response.status));
  return body;
}

export async function checkCloudBackend() {
  const root = apiRoot();
  if (!root) return { ok: false, d1: false, r2: false };
  const response = await fetch(root + "/v1/health", {
    method: "GET",
    headers: { Accept: "application/json" },
    cache: "no-store",
  });
  const type = String(response.headers.get("content-type") || "");
  if (!type.includes("application/json")) throw new Error("DEEPFORGE API is not deployed on this host.");
  const body = await response.json().catch(() => ({}));
  if (!response.ok || !body.ok) throw new Error(body.error || "DEEPFORGE D1 health check failed.");
  return body;
}

export async function cloudSignup(email, password, displayName) {
  const payload = await authRequest("/v1/auth/signup", {
    method: "POST",
    body: JSON.stringify({ email, password, displayName }),
  });
  return storeCloudAuth(payload);
}

export async function cloudLogin(email, password) {
  const payload = await authRequest("/v1/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });
  return storeCloudAuth(payload);
}

export async function loadCloudAuth() {
  const token = getCloudAuthToken();
  if (!token) return null;
  try {
    const payload = await authRequest("/v1/auth/me", {
      method: "GET",
      headers: { Authorization: "Bearer " + token },
    });
    return payload && payload.user ? payload.user : null;
  } catch (_) {
    clearCloudAuth();
    return null;
  }
}

export async function cloudLogout() {
  const token = getCloudAuthToken();
  try {
    if (token) {
      await authRequest("/v1/auth/logout", {
        method: "POST",
        headers: { Authorization: "Bearer " + token },
      });
    }
  } finally {
    clearCloudAuth();
  }
}

export async function deleteCloudAccount() {
  const token = getCloudAuthToken();
  if (!token) throw new Error("You are not logged in.");
  const payload = await authRequest("/v1/auth/account", {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token },
  });
  clearCloudAuth();
  return payload;
}

export async function loadCloudProfile() {
  const baseUser = await loadCloudAuth();
  if (!baseUser) return null;
  const token = getCloudAuthToken();
  const root = apiRoot();
  try {
    const response = await fetch(root + "/v1/profile/me", {
      method: "GET",
      headers: { Accept: "application/json", Authorization: "Bearer " + token },
      cache: "no-store",
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) return baseUser;
    return { ...baseUser, ...(body && body.user ? body.user : {}) };
  } catch (_) {
    return baseUser;
  }
}

export async function uploadCloudAvatar(file) {
  const token = getCloudAuthToken();
  if (!token) throw new Error("Log in before changing your profile picture.");
  if (!file) throw new Error("Choose an image first.");
  if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
    throw new Error("Use a PNG, JPG, or WebP image.");
  }
  if (file.size > 4 * 1024 * 1024) throw new Error("Profile images must be 4 MB or smaller.");
  const root = apiRoot();
  const response = await fetch(root + "/v1/profile/avatar", {
    method: "PUT",
    headers: { Authorization: "Bearer " + token, "Content-Type": file.type },
    body: file,
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || ("Avatar upload failed: " + response.status));
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("digitbox:cloud-auth-updated"));
  return body;
}

export async function deleteCloudAvatar() {
  const token = getCloudAuthToken();
  if (!token) throw new Error("Log in before changing your profile picture.");
  const root = apiRoot();
  const response = await fetch(root + "/v1/profile/avatar", {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token, Accept: "application/json" },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || ("Avatar delete failed: " + response.status));
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("digitbox:cloud-auth-updated"));
  return body;
}

export async function loadCloudSave(playerId) {
  const root = apiRoot();
  if (!root || !playerId) return null;
  const token = getCloudAuthToken();
  const response = await fetch(root + "/v1/save/" + encodeURIComponent(playerId), {
    method: "GET",
    headers: { Accept: "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
  });
  if (response.status === 404) {
    const type = String(response.headers.get("content-type") || "");
    if (type.includes("application/json")) return null;
    throw new Error("DEEPFORGE API route is missing on this host.");
  }
  if (!response.ok) throw new Error("Cloud load failed: " + response.status);
  return response.json();
}

export async function saveCloudSave(playerId, payload) {
  const root = apiRoot();
  if (!root || !playerId) return null;
  const token = getCloudAuthToken();
  const response = await fetch(root + "/v1/save/" + encodeURIComponent(playerId), {
    method: "PUT",
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error("Cloud save failed: " + response.status);
  return response.json();
}

async function clanRequest(path, options) {
  const root = apiRoot();
  if (!root) throw new Error("Cloudflare API is unavailable.");
  const response = await fetch(root + path, {
    ...options,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      ...((options && options.headers) || {}),
    },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || ("Clan request failed: " + response.status));
  return body;
}

export function clanEmblemUrl(clanId, version) {
  if (!clanId) return "";
  const root = apiRoot();
  if (!root) return "";
  return root + "/v1/clans/" + encodeURIComponent(clanId) + "/emblem" + (version ? "?v=" + encodeURIComponent(version) : "");
}

export async function uploadClanEmblem(clanId, file) {
  const root = apiRoot();
  const token = getCloudAuthToken();
  if (!root) throw new Error("Cloudflare API is unavailable.");
  if (!token) throw new Error("Log in before changing the clan emblem.");
  if (!file) throw new Error("Choose an image first.");
  const response = await fetch(root + "/v1/clans/" + encodeURIComponent(clanId) + "/emblem", {
    method: "PUT",
    headers: { Authorization: "Bearer " + token, "Content-Type": file.type || "application/octet-stream" },
    body: file,
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || ("Emblem upload failed: " + response.status));
  return body;
}

export async function deleteClanEmblem(clanId) {
  const root = apiRoot();
  const token = getCloudAuthToken();
  if (!root) throw new Error("Cloudflare API is unavailable.");
  if (!token) throw new Error("Log in before changing the clan emblem.");
  const response = await fetch(root + "/v1/clans/" + encodeURIComponent(clanId) + "/emblem", {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token, Accept: "application/json" },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || ("Emblem delete failed: " + response.status));
  return body;
}

export async function loadClans(playerId) {
  return clanRequest("/v1/clans?playerId=" + encodeURIComponent(playerId), { method: "GET" });
}

export async function createClan(playerId, name, tag, companyValue, trophies, accessToken) {
  return clanRequest("/v1/clans", {
    method: "POST",
    headers: accessToken ? { Authorization: "Bearer " + accessToken } : {},
    body: JSON.stringify({ playerId, name, tag, companyValue: Number(companyValue) || 0, trophies: Number(trophies) || 0 }),
  });
}

export async function joinClan(playerId, code, companyValue, trophies) {
  const token = getCloudAuthToken();
  return clanRequest("/v1/clans/join", {
    method: "POST",
    headers: token ? { Authorization: "Bearer " + token } : {},
    body: JSON.stringify({ playerId, code, companyValue: Number(companyValue) || 0, trophies: Number(trophies) || 0 }),
  });
}

export async function joinClanById(playerId, clanId, companyValue, trophies) {
  const token = getCloudAuthToken();
  return clanRequest("/v1/clans/join", {
    method: "POST",
    headers: token ? { Authorization: "Bearer " + token } : {},
    body: JSON.stringify({ playerId, clanId, companyValue: Number(companyValue) || 0, trophies: Number(trophies) || 0 }),
  });
}

export async function leaveClan(playerId) {
  return clanRequest("/v1/clans/leave", {
    method: "POST",
    body: JSON.stringify({ playerId }),
  });
}

export async function syncClanProfile(playerId, companyValue, trophies) {
  return clanRequest("/v1/clans/profile", {
    method: "PUT",
    body: JSON.stringify({ playerId, companyValue: Number(companyValue) || 0, trophies: Number(trophies) || 0 }),
  });
}
