import { useMemo, useState } from "react";
import { BUILDINGS } from "./data";
import { surfaceHeight } from "./world";

function distanceTo(player, city) {
  return Math.abs((Number(city && city.x) || 0) - (Number(player && player.x) || 0));
}

function directionTo(player, city) {
  const dx = (Number(city && city.x) || 0) - (Number(player && player.x) || 0);
  if (Math.abs(dx) < 1.2) return "HERE";
  return dx < 0 ? "←" : "→";
}

function drillToolName(level) {
  const n = Number(level) || 1;
  if (n <= 1) return "Rusty Pickaxe";
  if (n === 2) return "Iron Pickaxe";
  if (n === 3) return "Steel Pickaxe";
  if (n === 4) return "Pneumatic Pick";
  if (n === 5) return "Power Drill";
  return "Deepcore Drill Mk " + (n - 4);
}

export default function WorldCityOverlay(props) {
  const [directoryOpen, setDirectoryOpen] = useState(false);
  const [cityName, setCityName] = useState("");
  const [cityStyle, setCityStyle] = useState("industrial");
  const [createBusy, setCreateBusy] = useState(false);
  const [customizeOpen, setCustomizeOpen] = useState(false);
  const [upgradeOpen, setUpgradeOpen] = useState(false);
  const [customizeBusy, setCustomizeBusy] = useState(false);
  const [editName, setEditName] = useState("");
  const [editStyle, setEditStyle] = useState("industrial");
  const player = props.player || { x: 0, y: 0 };
  const cities = Array.isArray(props.cities) ? props.cities : [];
  const players = Array.isArray(props.players) ? props.players : [];
  const myCity = props.myCity || null;
  const waypoint = props.waypoint || myCity || null;

  const nearest = useMemo(() => {
    let best = null;
    let bestDistance = Infinity;
    cities.forEach((city) => {
      const d = distanceTo(player, city);
      if (d < bestDistance) {
        bestDistance = d;
        best = city;
      }
    });
    return best ? { city: best, distance: bestDistance } : null;
  }, [cities, player.x]);

  const depth = Number(player.y) - surfaceHeight(Number(player.x) || 0);
  const visiting = nearest && nearest.distance <= 7.5 && depth < 1.5 ? nearest.city : null;
  const isMyCity = Boolean(visiting && myCity && visiting.ownerId === myCity.ownerId);
  const orderedCities = useMemo(() => {
    return cities.slice().sort((a, b) => distanceTo(player, a) - distanceTo(player, b));
  }, [cities, player.x]);

  async function foundCity(event) {
    event.preventDefault();
    if (!props.onCreateCity || createBusy) return;
    setCreateBusy(true);
    try {
      const ok = await props.onCreateCity(cityName.trim() || "My Mining City", cityStyle);
      if (ok) setCityName("");
    } finally {
      setCreateBusy(false);
    }
  }

  async function saveCustomization(event) {
    event.preventDefault();
    if (!props.onCustomizeCity || customizeBusy || !myCity) return;
    setCustomizeBusy(true);
    try {
      const ok = await props.onCustomizeCity(editName.trim() || myCity.name || "My Mining City", editStyle);
      if (ok) setCustomizeOpen(false);
    } finally {
      setCustomizeBusy(false);
    }
  }

  function openCustomization() {
    if (!myCity) return;
    setEditName(myCity.name || "");
    setEditStyle(myCity.style || "industrial");
    setCustomizeOpen(true);
  }

  return (
    <div className="df-world-city-ui">
      <div className="df-mp-status">
        <span className="dot" />
        <b>{players.length}</b>
        <small>online miner{players.length === 1 ? "" : "s"}</small>
      </div>

      {waypoint && (
        <div className="df-city-waypoint">
          <small>{waypoint.ownerId === (myCity && myCity.ownerId) ? "YOUR CITY" : "VISITING"}</small>
          <b>{directionTo(player, waypoint)} {Math.round(distanceTo(player, waypoint))}m</b>
          <span>{waypoint.ownerName}</span>
        </div>
      )}

      <button className="df-city-directory-toggle" onClick={() => setDirectoryOpen((value) => !value)}>
        🏘 <b>CITIES</b>
      </button>

      {directoryOpen && (
        <aside className="df-city-directory">
          <header>
            <div><small>SHARED SURFACE</small><b>City directory</b></div>
            <button onClick={() => setDirectoryOpen(false)}>×</button>
          </header>
          <p>Track a city, then walk there. Tracking never teleports you.</p>
          <div className="df-city-directory-list">
            {orderedCities.length === 0 && <div className="empty">Log in and sync to discover player cities.</div>}
            {orderedCities.map((city) => {
              const mine = myCity && city.ownerId === myCity.ownerId;
              const active = waypoint && city.ownerId === waypoint.ownerId;
              return (
                <button key={city.ownerId} className={active ? "active" : ""} onClick={() => props.onWaypoint && props.onWaypoint(city)}>
                  <span className={city.online ? "city-online online" : "city-online"} />
                  <div>
                    <b>{city.ownerFortress ? "♛ OWNER FORTRESS" : mine ? "YOUR CITY" : city.ownerName + "'s city"}</b>
                    <small>{city.ownerFortress ? "∞ PROPERTY · ∞ ARMOR · 4 TURRETS" : "LV " + (Number(city.level) || 1)} · {Math.round(distanceTo(player, city))}m away · X {Math.round(city.x)}</small>
                  </div>
                  <em>{directionTo(player, city)}</em>
                </button>
              );
            })}
          </div>
        </aside>
      )}

      {props.myUserId && !myCity && (
        <aside className="df-city-founder">
          <div className="df-city-founder-head">
            <span>🏗</span>
            <div><small>NO CITY YET</small><b>Found your own city</b></div>
          </div>
          <p>Choose a name and visual style. Your city gets a permanent place in the shared world and starts at level 1.</p>
          <form onSubmit={foundCity}>
            <input
              value={cityName}
              maxLength={28}
              placeholder="e.g. Ironvale"
              onChange={(event) => setCityName(event.target.value)}
            />
            <div className="df-city-style-picker">
              {[
                ["industrial", "⚙", "Industrial"],
                ["frontier", "🪵", "Frontier"],
                ["steel", "🏢", "Steel"],
              ].map((style) => (
                <button type="button" key={style[0]} className={cityStyle === style[0] ? "active" : ""} onClick={() => setCityStyle(style[0])}>
                  <span>{style[1]}</span><b>{style[2]}</b>
                </button>
              ))}
            </div>
            <button className="df-city-found-button" disabled={createBusy}>{createBusy ? "FOUNDING…" : "FOUND CITY"}</button>
          </form>
        </aside>
      )}

      {visiting && (
        <aside className={"df-city-arrival" + (isMyCity ? " mine" : " visitor")}>
          <div className="df-city-arrival-head">
            <span>{isMyCity ? "🏚" : "🏙"}</span>
            <div>
              <small>{visiting.ownerFortress ? "♛ OWNER FORTRESS · ∞ ARMOR" : (isMyCity ? "YOU WALKED HOME" : "PLAYER CITY") + " · LEVEL " + (Number(visiting.level) || 1)}</small>
              <b>{visiting.name || (isMyCity ? "Your mining town" : visiting.ownerName + "'s city")}</b>
            </div>
            {isMyCity && (
              <div className="df-city-arrival-actions">
                <button className="df-city-upgrade-toggle" onClick={() => setUpgradeOpen((value) => !value)}>
                  {upgradeOpen ? "CLOSE UPGRADES" : "⬆ UPGRADE CITY"}
                </button>
                <button className="df-city-customize-toggle" onClick={openCustomization}>CUSTOMIZE</button>
              </div>
            )}
          </div>

          {isMyCity ? (
            <>
              <div className="df-city-compact-status">
                <span>{visiting.ownerFortress ? "♛" : "🏙"}</span>
                <div>
                  <small>{visiting.ownerFortress ? "OWNER FORTRESS" : "YOUR CITY"}</small>
                  <b>{visiting.ownerFortress ? "∞ armor · ∞ property · 4 turrets" : "Level " + (Number(visiting.level) || 1) + " · upgrades available inside city"}</b>
                </div>
              </div>

              {upgradeOpen && (
                <div className="df-city-upgrade-drawer">
                  {visiting.ownerFortress ? (
                    <div className="df-owner-fortress-status">
                      <div><small>PROPERTY VALUE</small><b>∞</b></div>
                      <div><small>FORTRESS ARMOR</small><b>∞</b></div>
                      <div><small>WALL TURRETS</small><b>{Number(visiting.turrets) || 4}</b></div>
                      <div><small>ALL CITY SYSTEMS</small><b>MAX</b></div>
                    </div>
                  ) : (
                    <>
                      <p><b>CITY LEVEL {Number(visiting.level) || 1}</b> · Every 4 total building upgrades raises the city level.</p>
                      <div className="df-city-town-upgrades">
                        {BUILDINGS.map((building) => {
                          const level = Math.max(Number(props.game.buildings && props.game.buildings[building.key]) || 0, Number(visiting.upgrades && visiting.upgrades[building.key]) || 0);
                          const cost = props.buildingCost ? props.buildingCost(building) : 0;
                          return (
                            <button key={building.key} onClick={() => props.upgradeBuilding && props.upgradeBuilding(building)}>
                              <span>{building.icon}</span>
                              <div><b>{building.name}</b><small>LEVEL {level} · {building.desc}</small></div>
                              <em>${cost.toLocaleString()}</em>
                            </button>
                          );
                        })}
                      </div>
                    </>
                  )}

                  <div className="df-city-upgrade-divider"><span>MINING TOOL SHOP</span></div>
                  <div className="df-city-tool-shop">
                    {(props.miningTools || []).map((tool) => {
                      const owned = Boolean(props.toolsOwned && props.toolsOwned[tool.key]);
                      const equipped = Boolean(props.equippedTool && props.equippedTool.key === tool.key);
                      return (
                        <button
                          key={tool.key}
                          className={equipped ? "equipped" : ""}
                          onClick={() => props.buyTool && props.buyTool(tool.key)}
                        >
                          <span>{tool.icon}</span>
                          <div>
                            <b>{tool.name}</b>
                            <small>Power {tool.power} · {tool.interval} ms · stamina {tool.stamina}</small>
                          </div>
                          <em>{equipped ? "EQUIPPED" : owned ? "EQUIP" : tool.cost === 0 ? "FREE" : "$" + tool.cost.toLocaleString()}</em>
                        </button>
                      );
                    })}
                  </div>

                  <div className="df-city-upgrade-divider"><span>SUPPLY DEPOT</span></div>
                  <div className="df-city-buildings">
                    {[
                      { key: "cargoMax", icon: "🛒", name: "Heavy Haul Cart", detail: props.game.cargoMax + " ore capacity" },
                      { key: "armor", icon: "🛡", name: "Reinforced Mining Suit", detail: props.game.maxHp + " protection" },
                      { key: "blaster", icon: "⚔", name: "Steel Mining Sword", detail: "Sword level " + props.game.blaster },
                    ].map((item) => {
                      const cost = props.gearCost ? props.gearCost(item.key) : 0;
                      return (
                        <button key={item.key} onClick={() => props.upgradeGear && props.upgradeGear(item.key)}>
                          <span>{item.icon}</span>
                          <div><b>{item.name}</b><small>{item.detail}</small></div>
                          <em>${cost.toLocaleString()}</em>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="df-city-visitor-stats">
              <div><small>{visiting.ownerFortress ? "PROPERTY VALUE" : "CITY LEVEL"}</small><b>{visiting.ownerFortress ? "∞" : Number(visiting.level) || 1}</b></div>
              <div><small>{visiting.ownerFortress ? "ARMOR" : "COMPANY"}</small><b>{visiting.ownerFortress ? "∞" : Number(visiting.companyValue || 0).toLocaleString()}</b></div>
              <div><small>{visiting.ownerFortress ? "TURRETS" : "STATUS"}</small><b>{visiting.ownerFortress ? Number(visiting.turrets) || 4 : visiting.online ? "ONLINE" : "OFFLINE"}</b></div>
            </div>
          )}
        </aside>
      )}

      {customizeOpen && myCity && (
        <aside className="df-city-customizer">
          <header><div><small>YOUR CITY</small><b>Customize city</b></div><button onClick={() => setCustomizeOpen(false)}>×</button></header>
          <form onSubmit={saveCustomization}>
            <input value={editName} maxLength={28} onChange={(event) => setEditName(event.target.value)} />
            <div className="df-city-style-picker">
              {[
                ["industrial", "⚙", "Industrial"],
                ["frontier", "🪵", "Frontier"],
                ["steel", "🏢", "Steel"],
              ].map((style) => (
                <button type="button" key={style[0]} className={editStyle === style[0] ? "active" : ""} onClick={() => setEditStyle(style[0])}>
                  <span>{style[1]}</span><b>{style[2]}</b>
                </button>
              ))}
            </div>
            <button className="df-city-found-button" disabled={customizeBusy}>{customizeBusy ? "SAVING…" : "SAVE CITY"}</button>
          </form>
        </aside>
      )}

      <style jsx global>{`
        .df-world-city-ui{pointer-events:none;position:absolute;inset:0;z-index:18}.df-world-city-ui button,.df-world-city-ui aside{pointer-events:auto}.df-mp-status{position:absolute;left:12px;top:58px;display:flex;align-items:center;gap:5px;padding:6px 8px;border:1px solid rgba(255,255,255,.09);border-radius:8px;background:rgba(14,23,27,.76);backdrop-filter:blur(8px);color:#c8d4d9}.df-mp-status .dot{width:7px;height:7px;border-radius:99px;background:#58d58b;box-shadow:0 0 9px rgba(88,213,139,.55)}.df-mp-status b{font-size:.65rem}.df-mp-status small{font-size:.52rem;color:#8d9da4}.df-city-waypoint{position:absolute;top:9px;left:50%;transform:translateX(-50%);min-width:155px;padding:6px 12px;border:1px solid rgba(255,220,141,.16);border-radius:9px;background:rgba(26,28,24,.78);backdrop-filter:blur(8px);text-align:center;color:#ead7ab}.df-city-waypoint small,.df-city-waypoint b,.df-city-waypoint span{display:block}.df-city-waypoint small{font-size:.42rem;letter-spacing:.14em;color:#a89266}.df-city-waypoint b{margin-top:1px;font-size:.72rem}.df-city-waypoint span{font-size:.5rem;color:#8f8777}.df-city-directory-toggle{position:absolute;right:12px;top:58px;min-height:34px;padding:0 10px;border:1px solid rgba(255,255,255,.1);border-radius:8px;background:rgba(14,23,27,.8);color:#cbd8dc;font-size:.58rem;cursor:pointer}.df-city-directory{position:absolute;right:12px;top:98px;width:min(320px,calc(100vw - 24px));max-height:58vh;overflow:auto;padding:11px;border:1px solid rgba(255,255,255,.09);border-radius:12px;background:rgba(14,22,25,.95);box-shadow:0 18px 50px rgba(0,0,0,.42);color:#d8e0e3}.df-city-directory header{display:flex;align-items:center;justify-content:space-between}.df-city-directory header small,.df-city-directory header b{display:block}.df-city-directory header small{font-size:.45rem;letter-spacing:.13em;color:#78919c}.df-city-directory header b{font-size:.82rem}.df-city-directory header button{width:28px;height:28px;border:0;border-radius:7px;background:rgba(255,255,255,.05);color:#9eabb0;cursor:pointer}.df-city-directory>p{margin:7px 0 9px;color:#84959c;font-size:.55rem;line-height:1.4}.df-city-directory-list{display:grid;gap:5px}.df-city-directory-list>button{display:flex;align-items:center;gap:8px;width:100%;padding:7px;border:1px solid rgba(255,255,255,.055);border-radius:8px;background:rgba(255,255,255,.025);color:#c7d0d4;text-align:left;cursor:pointer}.df-city-directory-list>button.active{border-color:rgba(224,190,111,.24);background:rgba(187,143,55,.09)}.df-city-directory-list .city-online{width:7px;height:7px;border-radius:99px;background:#606b70}.df-city-directory-list .city-online.online{background:#56ce86;box-shadow:0 0 8px rgba(86,206,134,.45)}.df-city-directory-list button>div{min-width:0;flex:1}.df-city-directory-list b,.df-city-directory-list small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.df-city-directory-list b{font-size:.58rem}.df-city-directory-list small{margin-top:2px;color:#77878e;font-size:.48rem}.df-city-directory-list em{font-style:normal;color:#d8bd7b;font-weight:900}.df-city-directory-list .empty{padding:9px;color:#708187;font-size:.55rem}.df-city-arrival{position:absolute;left:50%;bottom:9px;transform:translateX(-50%);width:min(620px,calc(100vw - 150px));padding:10px;border:1px solid rgba(255,255,255,.09);border-radius:12px;background:rgba(19,24,24,.92);box-shadow:0 16px 45px rgba(0,0,0,.4);color:#dbe1e0}.df-city-arrival.mine{border-color:rgba(213,176,95,.22);background:rgba(30,27,20,.94)}.df-city-arrival-head{display:flex;align-items:center;gap:8px}.df-city-arrival-actions{display:flex;align-items:center;gap:5px;margin-left:auto}.df-city-upgrade-toggle{min-height:30px;padding:0 10px;border:1px solid rgba(213,176,95,.22);border-radius:7px;background:linear-gradient(180deg,rgba(171,124,40,.16),rgba(94,68,28,.1));color:#e1c276;font-size:.47rem;font-weight:950;cursor:pointer}.df-city-arrival-head>span{font-size:1.2rem}.df-city-arrival-head small,.df-city-arrival-head b{display:block}.df-city-arrival-head small{font-size:.43rem;letter-spacing:.13em;color:#8d927f}.df-city-arrival-head b{font-size:.72rem}.df-city-arrival>p{margin:6px 0;color:#8e9999;font-size:.52rem}.df-city-tool-shop{display:grid;grid-template-columns:repeat(2,1fr);gap:5px}.df-city-tool-shop button{display:flex;align-items:center;gap:6px;min-width:0;padding:7px;border:1px solid rgba(255,255,255,.06);border-radius:8px;background:rgba(255,255,255,.025);color:#ddd1b7;text-align:left;cursor:pointer}.df-city-tool-shop button.equipped{border-color:rgba(93,208,141,.22);background:rgba(57,128,84,.08)}.df-city-tool-shop button>span{font-size:.95rem}.df-city-tool-shop button>div{min-width:0;flex:1}.df-city-tool-shop b,.df-city-tool-shop small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.df-city-tool-shop b{font-size:.52rem}.df-city-tool-shop small{font-size:.41rem;color:#7f796d}.df-city-tool-shop em{font-size:.46rem;font-style:normal;color:#d2b367}.df-city-tool-shop button.equipped em{color:#8ed0a8}.df-city-buildings{display:grid;grid-template-columns:repeat(4,1fr);gap:5px}.df-city-buildings button{display:flex;align-items:center;gap:6px;min-width:0;padding:7px;border:1px solid rgba(255,255,255,.06);border-radius:8px;background:rgba(255,255,255,.025);color:#ddd1b7;text-align:left;cursor:pointer}.df-city-buildings button>span{font-size:.9rem}.df-city-buildings button>div{min-width:0;flex:1}.df-city-buildings b,.df-city-buildings small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.df-city-buildings b{font-size:.52rem}.df-city-buildings small{font-size:.43rem;color:#7f796d}.df-city-buildings em{font-size:.48rem;font-style:normal;color:#d2b367}.df-city-visitor-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:8px}.df-city-visitor-stats>div{padding:7px;border-radius:7px;background:rgba(255,255,255,.03)}.df-city-visitor-stats small,.df-city-visitor-stats b{display:block}.df-city-visitor-stats small{font-size:.43rem;color:#718187}.df-city-visitor-stats b{margin-top:2px;font-size:.63rem}.df-city-compact-status{display:flex;align-items:center;gap:8px;margin-top:7px;padding:7px 9px;border:1px solid rgba(255,255,255,.05);border-radius:8px;background:rgba(255,255,255,.02)}.df-city-compact-status>span{font-size:.9rem}.df-city-compact-status small,.df-city-compact-status b{display:block}.df-city-compact-status small{font-size:.42rem;color:#83785f;letter-spacing:.08em}.df-city-compact-status b{margin-top:1px;font-size:.5rem;color:#aaa291}.df-city-upgrade-drawer{margin-top:7px;padding-top:7px;border-top:1px solid rgba(255,255,255,.055)}.df-city-upgrade-drawer>p{margin:0 0 6px;color:#8e887c;font-size:.5rem}.df-city-upgrade-divider{display:flex;align-items:center;gap:6px;margin:7px 0 5px}.df-city-upgrade-divider:before,.df-city-upgrade-divider:after{content:"";height:1px;flex:1;background:rgba(255,255,255,.05)}.df-city-upgrade-divider span{color:#766c5a;font-size:.4rem;letter-spacing:.12em}.df-city-town-upgrades{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin:6px 0}.df-city-town-upgrades button{display:flex;align-items:center;gap:6px;min-width:0;padding:7px;border:1px solid rgba(210,174,96,.1);border-radius:8px;background:rgba(174,127,52,.06);color:#ddd1b7;text-align:left;cursor:pointer}.df-city-town-upgrades button>span{font-size:.9rem}.df-city-town-upgrades button>div{min-width:0;flex:1}.df-city-town-upgrades b,.df-city-town-upgrades small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.df-city-town-upgrades b{font-size:.52rem}.df-city-town-upgrades small{font-size:.42rem;color:#837763}.df-city-town-upgrades em{font-size:.47rem;font-style:normal;color:#d2b367}.df-city-town-upgrades button:disabled{cursor:default;opacity:.82;border-color:rgba(107,209,232,.18);background:rgba(65,133,151,.08)}.df-owner-fortress-status{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin:7px 0}.df-owner-fortress-status>div{padding:7px;border:1px solid rgba(103,214,239,.16);border-radius:8px;background:linear-gradient(180deg,rgba(68,132,150,.14),rgba(33,67,78,.09));text-align:center}.df-owner-fortress-status small,.df-owner-fortress-status b{display:block}.df-owner-fortress-status small{font-size:.4rem;letter-spacing:.06em;color:#78a9b8}.df-owner-fortress-status b{margin-top:2px;color:#bfeaf4;font-size:.72rem}.df-city-founder{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);width:min(520px,calc(100vw - 24px));padding:12px;border:1px solid rgba(210,174,96,.2);border-radius:13px;background:rgba(28,25,20,.96);box-shadow:0 18px 50px rgba(0,0,0,.46);color:#ded4c1}.df-city-founder-head{display:flex;align-items:center;gap:8px}.df-city-founder-head>span{font-size:1.25rem}.df-city-founder-head small,.df-city-founder-head b{display:block}.df-city-founder-head small{font-size:.44rem;letter-spacing:.14em;color:#a18b5c}.df-city-founder-head b{font-size:.75rem}.df-city-founder>p{margin:7px 0;color:#8f887c;font-size:.55rem;line-height:1.4}.df-city-founder form{display:grid;gap:7px}.df-city-founder input{width:100%;height:38px;border:1px solid rgba(255,255,255,.09);border-radius:8px;outline:none;padding:0 10px;color:#ece3d4;background:rgba(0,0,0,.2);font-size:.66rem}.df-city-style-picker{display:grid;grid-template-columns:repeat(3,1fr);gap:5px}.df-city-style-picker button{min-height:42px;border:1px solid rgba(255,255,255,.07);border-radius:8px;background:rgba(255,255,255,.025);color:#9f9688;cursor:pointer}.df-city-style-picker button.active{border-color:rgba(211,177,104,.34);background:rgba(183,135,54,.12);color:#e2c482}.df-city-style-picker span,.df-city-style-picker b{display:block}.df-city-style-picker b{margin-top:1px;font-size:.5rem}.df-city-found-button{min-height:39px;border:0!important;border-radius:8px!important;background:linear-gradient(180deg,#d0ad66,#a78649)!important;color:#281f15!important;font-size:.62rem!important;font-weight:950!important;cursor:pointer}.df-city-found-button:disabled{opacity:.55}.df-city-founder input:focus{border-color:rgba(211,177,104,.4)}.df-city-customize-toggle{min-height:30px;padding:0 8px;border:1px solid rgba(210,174,96,.15);border-radius:7px;background:rgba(174,127,52,.08);color:#d0b272;font-size:.46rem;font-weight:900;cursor:pointer}.df-city-customizer{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(430px,calc(100vw - 24px));padding:12px;border:1px solid rgba(210,174,96,.2);border-radius:13px;background:rgba(27,24,20,.98);box-shadow:0 24px 70px rgba(0,0,0,.55);color:#ded4c1}.df-city-customizer header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}.df-city-customizer header small,.df-city-customizer header b{display:block}.df-city-customizer header small{font-size:.44rem;letter-spacing:.14em;color:#a18b5c}.df-city-customizer header b{font-size:.76rem}.df-city-customizer header>button{width:30px;height:30px;border:1px solid rgba(255,255,255,.07);border-radius:7px;background:rgba(255,255,255,.025);color:#b6aa98;cursor:pointer}.df-city-customizer form{display:grid;gap:7px}.df-city-customizer input{width:100%;height:38px;border:1px solid rgba(255,255,255,.09);border-radius:8px;outline:none;padding:0 10px;color:#ece3d4;background:rgba(0,0,0,.2);font-size:.66rem}.df-city-customizer input:focus{border-color:rgba(211,177,104,.4)}@media(max-width:720px){.df-city-arrival{width:calc(100vw - 20px);bottom:78px}.df-city-buildings,.df-city-town-upgrades,.df-city-tool-shop{grid-template-columns:1fr 1fr}.df-owner-fortress-status{grid-template-columns:1fr 1fr}.df-city-founder{bottom:82px}.df-city-directory-toggle{right:8px}.df-mp-status{left:8px}.df-city-waypoint{top:8px}}
      `}</style>
    </div>
  );
}
