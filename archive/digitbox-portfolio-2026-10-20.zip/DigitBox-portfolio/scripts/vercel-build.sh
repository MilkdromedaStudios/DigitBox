#!/usr/bin/env bash
set -euo pipefail

# Detect CI before the .env files are loaded — the committed .env.local
# contains captured VERCEL_* variables that would make local builds look
# like CI.
IS_CI_BUILD=""
if [ -n "${VERCEL:-}" ] || [ -n "${CF_PAGES:-}" ] || [ -n "${CI:-}" ]; then
  IS_CI_BUILD=1
fi

load_env_file() {
  local env_file="$1"
  if [ -f "${env_file}" ]; then
    echo "[build] Loading environment variables from ${env_file}"
    set -a
    # shellcheck disable=SC1090
    . "${env_file}"
    set +a
  fi
}

if [ -f ".env.local" ]; then
  load_env_file ".env.local"
elif [ -f ".env" ]; then
  load_env_file ".env"
fi

# The game HTML files are never part of the build: they are fetched at
# runtime from the GitHub release (see docs/GITHUB_RELEASE_ASSETS.md) or the
# Cloudflare R2 bucket (see docs/CLOUDFLARE_R2_SETUP.md). The build must NOT
# pull Git LFS objects — LFS bandwidth is limited and the files are huge.
export GIT_LFS_SKIP_SMUDGE=1

# public/projects contains large game files. Cloudflare Pages has no reason to
# upload or cache those files because the production worker streams them from
# GitHub on demand. On CI, DELETE the checkout copy instead of moving it to a
# hidden directory: moving it made Cloudflare's post-build cache upload scan a
# huge .build-excluded-projects tree and could leave deployments stuck at
# "Uploading to build output cache".
EXCLUDED_GAMES_DIR=".build-excluded-projects"
restore_excluded_games() {
  if [ -d "${EXCLUDED_GAMES_DIR}" ]; then
    rm -rf public/projects
    mv "${EXCLUDED_GAMES_DIR}" public/projects
  fi
}

rm -rf "${EXCLUDED_GAMES_DIR}"
if [ -d "public/projects" ]; then
  if [ -n "${IS_CI_BUILD}" ]; then
    rm -rf public/projects
    echo "[build] CI build: removed public/projects before build/cache upload; project files are streamed from GitHub at runtime"
  else
    mv public/projects "${EXCLUDED_GAMES_DIR}"
    echo "[build] Local build: temporarily excluding public/projects (moved to ${EXCLUDED_GAMES_DIR})"
    trap restore_excluded_games EXIT
  fi
fi

# When Cloudflare Pages builds this repo, expose that deployment's own
# Pages Functions URL to the browser. This keeps DEEPFORGE D1/R2 calls on
# the Pages project even when a custom frontend hostname differs.
if [ -z "${NEXT_PUBLIC_DEEPFORGE_API:-}" ] && [ -n "${CF_PAGES_URL:-}" ]; then
  export NEXT_PUBLIC_DEEPFORGE_API="${CF_PAGES_URL%/}"
  echo "[build] DEEPFORGE API -> ${NEXT_PUBLIC_DEEPFORGE_API}"
fi

echo "[build] Running next build..."
next build

# Vercel/CI can spend a long time uploading Next's incremental build cache
# after a successful build. It is not required to run the deployed site, so
# drop it in CI to keep deployments from hanging at "Uploading build output cache".
if [ -n "${IS_CI_BUILD}" ]; then
  rm -rf .next/cache
  echo "[build] Removed .next/cache before CI cache upload"
fi
