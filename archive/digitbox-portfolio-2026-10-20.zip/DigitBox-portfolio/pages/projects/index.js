export { default } from "../gallery";
