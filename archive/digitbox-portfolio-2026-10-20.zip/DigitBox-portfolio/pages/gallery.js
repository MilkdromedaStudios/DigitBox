import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { readLikes, toggleLike, LIKES_UPDATED_EVENT } from "../lib/likes";
import { readNotes, writeNotes } from "../lib/notes";

export default function GalleryPage() {
  const [projects, setProjects] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("all"); // "all" | "liked" | "appgpt"
  const [likes, setLikes] = useState([]);
  const [notes, setNotes] = useState("");
  const [notesSaved, setNotesSaved] = useState(true);

  const hydratedRef = useRef(false);

  useEffect(() => {
    loadProjects();
  }, []);

  useEffect(() => {
    setLikes(readLikes());
    setNotes(readNotes());
    hydratedRef.current = true;
    const sync = () => setLikes(readLikes());
    window.addEventListener(LIKES_UPDATED_EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(LIKES_UPDATED_EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  useEffect(() => {
    if (!hydratedRef.current) return undefined;
    const id = setTimeout(() => {
      writeNotes(notes);
      setNotesSaved(true);
    }, 400);
    return () => clearTimeout(id);
  }, [notes]);

  async function loadProjects() {
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/content/list?type=project");
      const payload = await res.json();
      if (!res.ok) {
        setError(payload.error || "Failed to load projects");
        return;
      }
      setProjects(payload.items || []);
    } catch {
      setError("Failed to load projects");
    } finally {
      setLoading(false);
    }
  }

  function onToggleLike(slug) {
    setLikes(toggleLike(slug));
  }

  const likedCount = useMemo(
    () => projects.filter((p) => likes.includes(p.slug)).length,
    [projects, likes]
  );

  const filtered = useMemo(() => {
    if (tab === "appgpt") return [];
    const q = query.trim().toLowerCase();
    let list = tab === "liked" ? projects.filter((p) => likes.includes(p.slug)) : projects;
    if (q) {
      list = list.filter((p) =>
        [p.title, p.name, p.slug]
          .filter(Boolean)
          .some((field) => String(field).toLowerCase().includes(q))
      );
    }
    return list;
  }, [projects, query, tab, likes]);

  return (
    <div className="content">
      <h1>Projects Gallery</h1>
      {error && tab !== "appgpt" && <p className="post-meta">{error}</p>}

      <div className="gallery-toolbar">
        {tab !== "appgpt" ? (
          <input
            type="search"
            className="auth-input gallery-search"
            placeholder="Search projects…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="Search projects"
          />
        ) : (
          <div className="post-meta">Build Telegram Mini Apps with AI.</div>
        )}
        <div className="gallery-tabs" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={tab === "all"}
            className={`gallery-tab${tab === "all" ? " is-active" : ""}`}
            onClick={() => setTab("all")}
          >
            All
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === "liked"}
            className={`gallery-tab${tab === "liked" ? " is-active" : ""}`}
            onClick={() => setTab("liked")}
          >
            ♥ Liked{likedCount ? ` (${likedCount})` : ""}
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === "appgpt"}
            className={`gallery-tab${tab === "appgpt" ? " is-active" : ""}`}
            onClick={() => setTab("appgpt")}
          >
            ✦ AppGPT
          </button>
        </div>
      </div>

      {tab === "appgpt" ? (
        <div className="gallery-grid">
          <figure className="gallery-item">
            <h2>AppGPT</h2>
            <p className="post-meta">Telegram AI App Builder</p>
            <p>
              Turn a chat into a working Telegram Mini App, keep editing the same app,
              inspect the code, preview it, debug it, and publish the generated index.html.
            </p>
            <div className="gallery-actions">
              <Link className="auth-btn action-btn" href="/appgpt">
                Open AppGPT
              </Link>
            </div>
          </figure>
        </div>
      ) : (
        <>
          {loading && <p className="post-meta">Loading projects…</p>}

          {!loading && !error && projects.length === 0 && (
            <p className="post-meta">No projects available yet.</p>
          )}

          {!loading && !error && projects.length > 0 && filtered.length === 0 && (
            <p className="post-meta">
              {tab === "liked"
                ? "No liked projects yet — tap ♥ Like on a project to save it here."
                : `No projects match “${query.trim()}”.`}
            </p>
          )}

          <div className="gallery-grid">
            {filtered.map((project) => {
              const liked = likes.includes(project.slug);
              return (
                <figure key={project.path} className="gallery-item">
                  <h2>{project.title}</h2>
                  <p className="post-meta">{project.name}</p>
                  <div className="gallery-actions">
                    <Link className="auth-btn action-btn" href={`/projects/${encodeURIComponent(project.slug)}`}>
                      Open
                    </Link>
                    <button
                      type="button"
                      className={`like-toggle${liked ? " is-liked" : ""}`}
                      onClick={() => onToggleLike(project.slug)}
                      aria-pressed={liked}
                      title={liked ? "Remove from liked" : "Add to liked"}
                    >
                      <span aria-hidden="true">{liked ? "♥" : "♡"}</span>
                      {liked ? "Liked" : "Like"}
                    </button>
                  </div>
                </figure>
              );
            })}
          </div>
        </>
      )}

      <section className="section notes-section">
        <div className="notes-head">
          <h2>Jot things down</h2>
          <span className="post-meta notes-status">{notesSaved ? "Saved on this device" : "Saving…"}</span>
        </div>
        <textarea
          className="auth-input notes-area"
          value={notes}
          onChange={(e) => {
            setNotes(e.target.value);
            setNotesSaved(false);
          }}
          placeholder="A scratchpad for anything — ideas, save codes, to-dos… kept on this device."
          rows={6}
          aria-label="Personal notes"
        />
      </section>
    </div>
  );
}
